# @pollinations/ui

Internal UI primitives, compositions, and modules for Pollinations apps.
SDK-backed subpaths consume auth state from
[`@pollinations/sdk/react`](../sdk/README.md#react-auth-provider); core
primitives and display recipes stay SDK-free.

## Install

> [!WARNING]
> **The `alpha` line (`0.1.0-alpha.x`) is unstable and breakage-prone.** It ships the in-progress design-system rebuild (new `--polli-color-*` token system, new primitives, renamed size props `sm|md|lg`) and its API may change between alpha versions without notice. The stable `latest` line is `0.0.2`. Opt into the alpha deliberately, and pin an exact version.

```bash
# stable (recommended)
npm install @pollinations/ui

# alpha (in-progress rebuild — pin exactly)
npm install @pollinations/ui@alpha
```

Install `@pollinations/sdk` too when using the
`@pollinations/ui/app-user-menu/sdk` subpath.

## Usage

```tsx
import "@pollinations/ui/styles.css";
import { PolliProvider } from "@pollinations/sdk/react";
import { Surface } from "@pollinations/ui";
import { AppUserMenu } from "@pollinations/ui/app-user-menu/sdk";

export function App() {
    return (
        <PolliProvider appKey="pk_your_publishable_key" permissions={["profile"]}>
            <Surface>
                <AppUserMenu dashboardHref="https://enter.pollinations.ai" />
            </Surface>
        </PolliProvider>
    );
}
```

### CDN / `<script>` Tag

The root `@pollinations/ui` entry also ships a browser IIFE bundle for
no-build pages. It exposes SDK-free primitives and compositions on
`window.PollinationsUI`. Non-root subpaths such as `@pollinations/ui/auth`,
`@pollinations/ui/wallet`, `@pollinations/ui/gen`, and
`@pollinations/ui/app-user-menu/sdk` remain ESM/CJS-only.

React 19 no longer ships UMD builds, so load React from an ESM CDN first, set
the globals expected by the IIFE bundle, then load `@pollinations/ui`:

```html
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/@pollinations/ui@alpha/styles.css"
/>
<div id="root"></div>
<script type="module">
  import React from "https://esm.sh/react@19";
  import * as ReactDOM from "https://esm.sh/react-dom@19";
  import * as ReactDOMClient from "https://esm.sh/react-dom@19/client";

  window.React = React;
  window.ReactDOM = { ...ReactDOM, ...ReactDOMClient };

  await new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/@pollinations/ui@alpha";
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });

  const { Button } = window.PollinationsUI;

  window.ReactDOM.createRoot(document.getElementById("root")).render(
    React.createElement(Button, null, "Generate"),
  );
</script>
```

The browser bundle keeps React and ReactDOM external via those globals, but it
does bundle the root entry's package dependencies, including Ark UI,
react-markdown, remark, and rehype.

React's guidance on loading React 19 without UMD builds:
https://react.dev/blog/2024/04/25/react-19-upgrade-guide#umd-builds-removed

For Pollinations apps that use unprefixed Tailwind utilities, import the
package-owned app stylesheet instead:

```css
@import "@pollinations/ui/app.css";
```

`app.css` includes `styles.css`, the Pollinations UI Tailwind theme bridge,
and generic `polli-ui-root`, `polli-ui-body`, and `polli-ui-shell` classes.

Canonical Pollinations source SVGs are exported from the package:

```ts
import markUrl from "@pollinations/ui/brand/mark.svg";
import lockupUrl from "@pollinations/ui/brand/lockup-horizontal.svg";
```

The SVG sources use `currentColor`. Apps control the rendered color by inlining
them or using them as masks. Root-level favicon, PWA icon, and SEO files stay
app-owned.

The whole kit derives from two atomic sources — `mark.svg` and `wordmark.svg`
(both `currentColor`) plus the raster bee `polli/polli.png`. One zero-config
command rebuilds everything:

```bash
npm run brand
```

It refreshes the committed derivatives in `src/brand`, and writes every
favicon / PWA / apple-touch / maskable / OG / social asset to `brand-out/`
(gitignored) — copy those into a site's `public/`. Colours are fixed to the two
brand themes matching enter.pollinations.ai (icons gold on transparent,
OG/social dark on cream), resolved from `theme-palette.json`. Sizes and padding
are data in `scripts/brand/presets.js` — `pad` keeps avatars clear of a circular
mask; add a platform by adding a line.

Wallet colors and utilities are bundled into the main stylesheet
(`@pollinations/ui/styles.css`) — no separate import needed.

## What's exported

- `@pollinations/ui` exports SDK-free design primitives, helpers, and
  compositions. These can be used without Pollinations auth.
- `@pollinations/ui/auth` exports SDK-free auth modal pieces:
  `AuthModal`, `AuthModalHeader`, `AuthModalLoading`, `AuthInfoCard`, and
  `ErrorBanner`.
- `@pollinations/ui/auth/sdk` exports identity/session components that read
  from the surrounding `<PolliProvider>`:
  - **null when not logged in (or before data loads):** `UserAvatar`,
    `UserName`, `WhenLoggedIn`.
  - **shown only when logged out:** `LoginButton`, `WhenLoggedOut`.

  These are intentionally bare wrappers around `useAuth*` hooks. They render
  the data and nothing else — no default copy and no default intent. The app
  composes layout, copy, and color.
- `@pollinations/ui/wallet` exports SDK-free wallet-specific display helpers
  and recipes: `formatPollen`, `PaidChip`, `TierChip`, `WalletKindIcon`,
  `WalletBalanceCard`, `PAID_BALANCE_CHART_COLOR`, and
  `TIER_BALANCE_CHART_COLOR`.
- `@pollinations/ui/app-user-menu/sdk` exports the SDK-backed app account
  menu module.
- `@pollinations/ui/gen` exports generation UI modules and modality helpers:
  `ModelSelector`, `ModalityChip`, `ModalityDot`, `ModalityTab`,
  `categoryLabel`, and `getModalityKey`.
- `@pollinations/ui/brand/*` exports the canonical brand kit — `mark`,
  `wordmark`, `lockup-horizontal`, `lockup-stacked` (currentColor SVG masters
  plus `-black`/`-white` SVG + PNG), and the `polli/` mascot PNGs.
- **Design primitives** — `Button`, `ButtonGroup`, `Chip`, `ChevronIcon`,
  `Dialog`, `DialogTitle`, `Dropdown`, `DropdownItem`, `Field`, `Heading`,
  `IconButton`, `InlineLink`, `Input`, `ScrollArea`, `Slider`, `Surface`,
  `Switch`, `TabButton`, `Table`, `TableBody`, `TableCell`, `TableHead`,
  `TableHeaderCell`, `TableRow`, `Text`, `Textarea`, `Tooltip`.
- **Design compositions** — `Alert`, `CodeBlock`, `Collapsible`,
  `CopyButton`, `EditableCombobox`, `EditableComboboxToken`,
  `ExternalLinkButton`, `FieldStack`, `FileUpload`, `InfoTip`, `LinkCard`,
  `Markdown`, `MediaPlaceholder`, `MultiSelect`, `NavItem`, `PeriodPicker`,
  `Prose`, `Section`, `StatCard`.
  `FieldStack` supports label, helper, action, error, and opt-in aligned label
  rows for compact forms.
  `EditableCombobox.startContent` renders content inside a wrapping input shell
  and replaces the standalone chevron trigger.
- **Helpers** — `cn`, `useScrollLock`, `currentPeriod`,
  `getPeriodBucketKeys`, `periodBucketKeyToDate`.

For per-request usage data and other dynamic queries, call the opt-in hooks
from `@pollinations/sdk/react` (`useAccountKeyUsage`, `useAccountKey`,
`useAccountBalance`, etc.) directly.

## Source Layout

- `src/primitives/*` contains generic, SDK-free building blocks.
- `src/compositions/*` contains SDK-free recipes that compose primitives.
- `src/modules/*` contains package-owned recipes with domain assumptions
  such as auth, wallet, app-user-menu, and gen.
- Public subpath exports (`@pollinations/ui/auth`,
  `@pollinations/ui/wallet`, `@pollinations/ui/gen`,
  `@pollinations/ui/app-user-menu/sdk`) are built directly from those source
  layers.

## Theming

Import `@pollinations/ui/styles.css` once at the app entry. The package uses a
single app accent by default; primitives read the current cascade through
`--polli-color-*` variables.

Use `data-theme="neutral"` on chrome that should carry no accent, such as a
global rail. Use `data-theme="accent"` inside a neutral subtree to re-assert
the app accent for controls. Do not use per-component theme props; compose
layout and state with primitives instead.

## Public design tokens

These CSS variables are part of the public contract. You may reference
them in your own CSS / inline styles. Renames between minor versions
count as breaking.

Public tokens sit under the `--polli-*` namespace so they do not collide
with host app tokens.

**Accent-aware (resolve against the current accent or neutral scope):**

| Token                         | Purpose                                       |
| ----------------------------- | --------------------------------------------- |
| `--polli-color-text-base`     | Default body text on themed surfaces.         |
| `--polli-color-text-strong`   | Emphasized text / headings.                   |
| `--polli-color-text-soft`     | Accent text (more saturated than base).       |
| `--polli-color-text-muted`    | De-emphasized text (lighter than base).       |
| `--polli-color-border`        | Default border on themed surfaces.            |
| `--polli-color-bg-subtle`     | Large panel surface (semi-transparent).       |
| `--polli-color-bg-active`     | Selected / active state background.           |
| `--polli-color-bg-hover`      | Hover state background.                       |
| `--polli-color-bg-pale`       | Light wash (cards, chips, large blocks).      |
| `--polli-color-scrollbar-thumb` | Active themed scrollbar thumb color.        |

**Static app tokens:**

| Token                         | Purpose                                       |
| ----------------------------- | --------------------------------------------- |
| `--polli-font-heading`        | Heading display face.                         |
| `--polli-font-subheading`     | Secondary display face.                       |
| `--polli-font-body`           | Body text face.                               |
| `--polli-font-pixel`          | Pixel/monospace fallback stack.               |
| `--polli-text-micro`          | Micro label size.                             |
| `--polli-text-base`           | Base text size.                               |
| `--polli-color-surface-white` | Translucent white surface.                    |

Wallet tokens are public (bundled into `@pollinations/ui/styles.css`):

| Token                         | Purpose                                       |
| ----------------------------- | --------------------------------------------- |
| `--polli-color-paid-pale`     | Paid-balance wash.                            |
| `--polli-color-paid-soft`     | Paid-balance marker.                          |
| `--polli-color-paid-deep`     | Paid-balance text.                            |
| `--polli-color-tier-pale`     | Quest Pollen wash.                            |
| `--polli-color-tier-soft`     | Quest Pollen marker.                          |
| `--polli-color-tier-deep`     | Quest Pollen text.                            |

**Intent (theme-independent):**

| Token                                      | Purpose                          |
| ------------------------------------------ | -------------------------------- |
| `--polli-color-danger-bg-light`            | Error surface background.        |
| `--polli-color-danger-text`                | Error text foreground.           |
| `--polli-color-danger-border`              | Error border.                    |
| `--polli-color-success-text`               | Success text foreground.         |
| `--polli-color-success-bright`             | Filled success background.       |
| `--polli-color-success-text-on-bright`     | Text on filled success surfaces. |
| `--polli-color-warning-bg-light`           | Warning surface background.      |
| `--polli-color-warning-text`               | Warning text foreground.         |

**Example:**

```css
.my-themed-card {
  background: var(--polli-color-bg-pale);
  color: var(--polli-color-text-base);
  border: 1px solid var(--polli-color-border);
}
```

Anything not listed above, including the `polli:*` Tailwind utility class
names, is library-internal and may change without notice.
